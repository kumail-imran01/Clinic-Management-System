package src;

public abstract class  Doctor {

    public abstract void Prescription();
    public abstract void write_prescription(String time);
    public abstract void searchPatientHistory();

}
