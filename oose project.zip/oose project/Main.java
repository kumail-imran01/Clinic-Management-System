import java.sql.*;
import java.util.Date;
public class Main {
    public static void main(String[] args) {
        System.out.println("MySQL Connect Example.");
        Connection conn = null;
        String url = "jdbc:mysql://localhost:3306/";
        String dbName = "oose2";
        String driver = "com.mysql.jdbc.Driver";
        String userName = "root";
        String password = "root";
        try {
            conn = DriverManager.getConnection(url + dbName, userName, password);
            String query = "Update Patient set pharmacy_medicine='disprin',lab_test='Blood' where patient_id=2";

            // create the java statement
            Statement st = conn.createStatement();

            // execute the query, and get a java resultset
            ResultSet rs = st.executeQuery(query);

            // iterate through the java resultset
            while (rs.next())
            {
                int doctor_id = rs.getInt("doctor_id");
                String admin_Name = rs.getString("admin_name");
                String doctor_name = rs.getString("doctor_name");
                String specialization = rs.getString("specialization");
                String gender= rs.getString("gender");
                Date dateofBirth = rs.getDate("dob");
                int age=rs.getInt("age");
                String username=rs.getString("doctor_username");
                String passwords=rs.getString("PasswordHash");

                // print the results
                System.out.format("%s, %s, %s, %s, %s, %s, %s, %s, %s \n", doctor_id,admin_Name,doctor_name,specialization,gender,dateofBirth,age,username,passwords);
            }
            st.close();
        } catch (Exception e) {
            e.printStackTrace();
        }

    }
}
